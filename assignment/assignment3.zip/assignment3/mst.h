#ifndef MST_H
#define MST_H
#define MAX(x,y) ((x)>(y)?(x):(y))
extern int num_pt;
extern int outputfile;
void MST(int MAX_X,int MAX_Y,int x_coordinate[],int y_coordinate[]);
#endif
